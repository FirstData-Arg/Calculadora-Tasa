$( document ).ready(function() {
	 smoothScroll.init();
   $('.trigger').on('click', function(){
		$('nav.mobile').slideToggle('slow');
	   
   });
   
setTimeout(function(){ 
  $('nav.mobile').on('click', function(){
		$('nav.mobile').slideUp('slow');
	   
   });
}, 1000);

$('.list-news ul li a').on('click', function(){
	$('#tabs').tab(); 
	
	var idLink = $(this).attr('href');
	setTimeout(function(){ 
		$('html,body').animate({
			scrollTop: $(idLink).offset().top
		}, 1500);   
	}, 100);
});  




$('#consulta').on('change', function(){
	
	var valSelect = $('#consulta').val();
	
	
	if(valSelect != 'online'){
		$('.online').hide();	
		$('.non-online').show();	
			
	} else {
		$('.non-online').hide();		
		$('.online').show();		
	}
	

});





   
});